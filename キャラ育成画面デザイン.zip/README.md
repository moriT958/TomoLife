
  # キャラ育成画面デザイン

  This is a code bundle for キャラ育成画面デザイン. The original project is available at https://www.figma.com/design/ILWh18qleOPEpAw2R5vyYs/%E3%82%AD%E3%83%A3%E3%83%A9%E8%82%B2%E6%88%90%E7%94%BB%E9%9D%A2%E3%83%87%E3%82%B6%E3%82%A4%E3%83%B3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  